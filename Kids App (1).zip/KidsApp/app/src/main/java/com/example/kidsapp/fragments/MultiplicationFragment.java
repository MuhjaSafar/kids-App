package com.example.kidsapp.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class MultiplicationFragment extends Fragment {
    private TextView questionTextView;
    private EditText answerEditText;
    private Button submitBtn;
    private TextView resultTextView;

    private int num1, num2;
    private int correctAnswer;
    private int questionCounter;
    private int totalQuestions = 10;
    private int getCorrectAnswer = 0;
    private int getInCorrectAnswer = 0;
    private int score = 0;
    FirebaseDatabase database;

    ProgressDialog progressDialog;

    public MultiplicationFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_multiplication, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        questionTextView = view.findViewById(R.id.questionTextView);
        answerEditText = view.findViewById(R.id.answerEditText);
        submitBtn = view.findViewById(R.id.submitBtn);
        resultTextView = view.findViewById(R.id.resultTextView);
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        generateQuestion();
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void generateQuestion() {
        if (questionCounter < totalQuestions) {
            Random random = new Random();
            num1 = random.nextInt(10) + 1; // Generate a random number between 1 and 10
            num2 = random.nextInt(10) + 1; // Generate a random number between 1 and 10
            correctAnswer = num1 * num2;

            questionTextView.setText(num1 + " x " + num2 + " =");
            answerEditText.setText("");


            questionCounter++;
        } else {
            questionTextView.setText(R.string.quiz_completed);
            answerEditText.setEnabled(false);
            submitBtn.setEnabled(false);
            answerEditText.setText(R.string.your_total_score_is + getCorrectAnswer);

            AlertDialog dialog = new AlertDialog.Builder(requireActivity())
                    .setTitle("Game Over")
                    .setMessage("Your Total Score is " + score + " Correct Answer = " + getCorrectAnswer + " And \n" + "Incorrect Answers = " + getInCorrectAnswer)
                    .create();
            dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  progressDialog.show();
                    dialog.dismiss();
                    database = FirebaseDatabase.getInstance();
                    database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("score").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        Integer dbScore = snapshot.getValue(Integer.class);
                                        if (dbScore == null) {
                                            dbScore = 0;
                                        }
                                        int totalScore = dbScore + score;
                                        database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .child("score").setValue(totalScore).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        progressDialog.dismiss();
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(requireContext(), "Score Saved", Toast.LENGTH_SHORT).show();
                                                        } else {
                                                            Toast.makeText(requireContext(), "Failed to Store Score", Toast.LENGTH_SHORT).show();

                                                        }
                                                        findNavController(MultiplicationFragment.this).navigateUp();

                                                    }
                                                });
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                }
            });
            dialog.setCancelable(false);
            dialog.show();

        }
    }

    private void checkAnswer() {
        String userAnswerStr = answerEditText.getText().toString();

        if (!userAnswerStr.isEmpty()) {
            int userAnswer = Integer.parseInt(userAnswerStr);

            if (userAnswer == correctAnswer) {
                resultTextView.setText(R.string.correct);
                getCorrectAnswer += 1;
                score += 5;

            } else {
                resultTextView.setText("Incorrect. The correct answer is " + correctAnswer);
                getInCorrectAnswer += 1;
            }

            generateQuestion();
        }
    }
}