package com.example.kidsapp.auth;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kidsapp.R;
import com.example.kidsapp.databinding.ActivityRegisterBinding;
import com.example.kidsapp.model.UserData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    ActivityRegisterBinding binding;
    private FirebaseAuth mAuth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;
    ProgressDialog progressDialog;
    String name, email, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        reference = firebaseDatabase.getReference("Users");

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);

        clickListeners();
    }

    private void clickListeners() {
        binding.llBottom.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        });

        binding.btnRegister.setOnClickListener(v -> {
            String name = binding.nameEt.getText().toString().trim();
            String email = binding.emailEt.getText().toString().trim();
            String password = binding.passET.getText().toString().trim();

            if (isValidated()) {
                progressDialog.show();
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            UserData userData = new UserData(id, name, email, "", "English", 0, 0);
                            userData.setScore(0);
                            reference.child(id).setValue(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    progressDialog.hide();
                                    if (task.isSuccessful()) {
                                        showToast("Successfully Registered");
                                        finish();
                                    } else {
                                        showToast(task.getException().getMessage());
                                    }
                                }
                            });
                        } else {
                            progressDialog.hide();
                            showToast(task.getException().getMessage());
                        }
                    }
                });
            }

        });

    }

    private Boolean isValidated() {
        name = binding.nameEt.getText().toString().trim();
        email = binding.emailEt.getText().toString().trim();
        password = binding.passET.getText().toString().trim();

        if (name.isEmpty()) {
            showToast("Please enter name");
            return false;
        }
        if (email.isEmpty()) {
            showToast("Please enter email");
            return false;
        }
        if (!(Patterns.EMAIL_ADDRESS).matcher(email).matches()) {
            showToast("Please enter email in correct format");
            return false;
        }
        if (password.isEmpty()) {
            showToast("Please enter password");
            return false;
        }

        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


}