package com.example.kidsapp.model;

public class MonthModel {
    String title;

    public MonthModel(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
