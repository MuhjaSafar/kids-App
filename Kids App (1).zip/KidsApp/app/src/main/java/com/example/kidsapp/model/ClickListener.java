package com.example.kidsapp.model;

public interface ClickListener  {
    public void selected(int position);
}
