package com.example.kidsapp.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DigitMemorizationFragment extends Fragment {
    private TextView digitTextView;
    private Button recallButton;
    private int[] digits = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
    private List<Integer> shownDigits;
    private int currentIndex = 0;
    private Handler handler;
    private Runnable digitRunnable;
    private boolean isUserInputEnabled;

    public DigitMemorizationFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_digit_memorization, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        digitTextView = view.findViewById(R.id.digitTextView);
        recallButton = view.findViewById(R.id.recallButton);
        shownDigits=new ArrayList<>();

        handler = new Handler();
        digitRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentIndex < digits.length) {
                    int digit = digits[currentIndex];
                    showDigit(digit);
                    shownDigits.add(digit);
                    currentIndex++;
                    handler.postDelayed(this, 2000);
                } else {
                    // All digits have been shown
                    isUserInputEnabled = true;
                    recallButton.setEnabled(true);
                }
            }
        };

        recallButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recallDigits();
            }
        });

        handler.postDelayed(digitRunnable, 2000);
    }


    private void showDigit(int digit) {
        digitTextView.setText(String.valueOf(digit));
        animateDigit();
    }

    private void animateDigit() {
        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setDuration(1000);
        digitTextView.startAnimation(fadeIn);
    }

    private void recallDigits() {
        if (!isUserInputEnabled) {
            return;
        }

        // Compare the user's input with the shown digits
        // Implement your desired logic here

        // Clear the shown digits and reset the state
        shownDigits.clear();
        currentIndex = 0;
        isUserInputEnabled = false;
        recallButton.setEnabled(false);

        // Generate a new sequence of digits for the next round
        generateNewSequence();
    }

    private void generateNewSequence() {
        // Shuffle the digits array
        shuffleArray(digits);

        // Restart the digit display process
        handler.postDelayed(digitRunnable, 2000);
    }

    // Helper method to shuffle an array using Fisher-Yates algorithm
    private void shuffleArray(int[] array) {
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Stop the handler when the activity is destroyed
        handler.removeCallbacks(digitRunnable);
    }
}
