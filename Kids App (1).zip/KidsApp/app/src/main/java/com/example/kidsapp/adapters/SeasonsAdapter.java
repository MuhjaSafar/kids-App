package com.example.kidsapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.kidsapp.R;
import com.example.kidsapp.databinding.ListImagesBinding;
import com.example.kidsapp.model.SeasonsModel;

import java.util.List;

public class SeasonsAdapter extends RecyclerView.Adapter<SeasonsAdapter.Vh> {

    List<SeasonsModel> list;
    Context context;

    public SeasonsAdapter(List<SeasonsModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.list_images,parent,false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        SeasonsModel model=list.get(position);
        holder.binding.img.setImageResource(model.getImage());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListImagesBinding binding;
        public Vh(@NonNull View itemView) {
            super(itemView);
            binding= ListImagesBinding.bind(itemView);
        }
    }
}
