package com.example.kidsapp.fragments;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;


import com.example.kidsapp.R;
import com.example.kidsapp.adapters.SeasonsAdapter;
import com.example.kidsapp.databinding.FragmentSeasonsBinding;
import com.example.kidsapp.model.SeasonsModel;

import java.util.ArrayList;
import java.util.List;

public class SeasonsFragment extends Fragment {

    FragmentSeasonsBinding binding;
    SeasonsAdapter adapter;
    List<SeasonsModel> list;
    private Handler handler;
    private Runnable runnable;
    private int delayTime = 5000;

    public SeasonsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentSeasonsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        list = new ArrayList<>();

        list.add(new SeasonsModel("Autumn", R.drawable.autumns));
        list.add(new SeasonsModel("Spring", R.drawable.spring));
        list.add(new SeasonsModel("Summer", R.drawable.summer));
        list.add(new SeasonsModel("Winter", R.drawable.winter));

        adapter = new SeasonsAdapter(list, requireContext());
        binding.vpSeasons.setAdapter(adapter);
        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentItem = binding.vpSeasons.getCurrentItem();
                if (currentItem == list.size() - 1) {
                    currentItem = 0;
                }
                binding.vpSeasons.setCurrentItem(currentItem + 1);
            }
        });
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentItem = binding.vpSeasons.getCurrentItem();
                if (currentItem != 0) {
                    binding.vpSeasons.setCurrentItem(currentItem - 1);
                }
            }
        });

        // Set up the PageTransformer for animation
        binding.vpSeasons.setPageTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                // Apply the animation to the current page and adjacent pages
                animateImageTransition(page, position);
                String name = list.get((int) binding.vpSeasons.getCurrentItem()).getName();
                binding.tvNAme.setText(name);
            }
        });
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = binding.vpSeasons.getCurrentItem();
                int totalItems = binding.vpSeasons.getAdapter().getItemCount();

                if (currentItem == totalItems - 1) {
                    binding.vpSeasons.setCurrentItem(0);
                } else {
                    binding.vpSeasons.setCurrentItem(currentItem + 1);
                }

                // Schedule the next auto-scroll
                handler.postDelayed(runnable, delayTime);
            }
        };
    }

    private void animateImageTransition(View page, float position) {
        // Load the animation from the XML file
        AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(requireContext(), R.animator.new_anim);

        // Apply the animation to the current page
        animatorSet.setTarget(page);
        animatorSet.start();
    }

    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(runnable, delayTime);

    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable);

    }
}