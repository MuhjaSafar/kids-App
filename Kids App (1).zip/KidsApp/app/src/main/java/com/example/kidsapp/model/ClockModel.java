package com.example.kidsapp.model;

public class ClockModel {
    String title;
    int hours;
    int minutes;

    public ClockModel(String title, int hours, int minutes) {
        this.title = title;
        this.hours = hours;
        this.minutes = minutes;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }
}
