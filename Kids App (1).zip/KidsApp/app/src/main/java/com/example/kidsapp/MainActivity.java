package com.example.kidsapp;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.kidsapp.databinding.ActivityMainBinding;
import com.example.kidsapp.model.UserData;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    BottomNavigationView bottomNavigationView;
    NavHostFragment navHostFragment;
    NavController navController;
    AppBarConfiguration appBarConfiguration;
    FirebaseDatabase database;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);

        bottomNavigationView = binding.bottomNavigationView;
        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        assert navHostFragment != null;
        navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(bottomNavigationView, navController);

        appBarConfiguration = new AppBarConfiguration.Builder(R.id.homeFragment2, R.id.profileFragment2)
                .build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        database= FirebaseDatabase.getInstance();

        database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.hide();

                if (snapshot.exists()){
                    Log.d("TAGSnap", "onDataChange1: ");
                    UserData data=snapshot.getValue(UserData.class);

                    assert data != null;
                    if (Objects.equals(data.getLanguage(), "English")){
                        setAppLanguage("en");
                    }
                    else {

                        setAppLanguage("tr");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.hide();
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            if (destination.getId() == R.id.homeFragment2) {
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.home);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
            } else if (destination.getId() == R.id.profileFragment2){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.profile);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
             //   toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.analogClockFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.analog_clock_fragment);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                   toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.digitalClockFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.digital_clock_fragment);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                   toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.seasonsFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.seasons_fragment);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.monthDaysFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.months_of_the_year);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.weekDaysFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.week_days);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.multiplicationFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.learn_multiplication);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.spellingWritingFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.learn_spelling_writing);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }

            else if (destination.getId() == R.id.ballFocusFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.learn_ball_focus);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.findSimilarImagesFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.find_simmiler_images);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.learnDirectionsFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.learn_directions);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
            else if (destination.getId() == R.id.digitMemorizationFragment){
                Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.learn_random_digits);
                toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
                toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_ios_new_24);
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
    private void setAppLanguage(String languageCode) {
        Locale locale = new Locale(languageCode);
        Configuration overrideConfiguration = new Configuration();
        overrideConfiguration.setLocale(locale);

        Context updatedContext = createConfigurationContext(overrideConfiguration);
        getResources().updateConfiguration(overrideConfiguration, getResources().getDisplayMetrics());
    }
}
