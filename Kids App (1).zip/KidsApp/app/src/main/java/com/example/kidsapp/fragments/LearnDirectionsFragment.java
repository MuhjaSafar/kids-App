package com.example.kidsapp.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kidsapp.R;
import com.example.kidsapp.databinding.FragmentLearnDirectionsBinding;

public class LearnDirectionsFragment extends Fragment {
    FragmentLearnDirectionsBinding binding;
    private ImageView directionImageView;
    private TextView directionTextView;

    private int currentDirection = 0;// 0: Up, 1: Down, 2: Left, 3: Right

    public LearnDirectionsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentLearnDirectionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        directionImageView = view.findViewById(R.id.directionImageView);
        directionTextView = view.findViewById(R.id.directionTextView);
        binding.changeDirectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeDirection();
            }
        });
        // Show initial direction
     //   showDirection(R.drawable.baseline_arrow_forward_ios_24, getString(R.string.direction_left));
    }
    private void changeDirection() {
        currentDirection = (currentDirection + 1) % 4; // Cycle through 0 to 3
        int imageResource;
        String directionText;
        switch (currentDirection) {
            case 0:
                imageResource = R.drawable.baseline_arrow_upward_24;
                directionText = getString(R.string.direction_top);
                break;
            case 1:
                imageResource = R.drawable.baseline_arrow_downward_24;
                directionText = getString(R.string.direction_bottom);
                break;
            case 2:
                imageResource = R.drawable.baseline_arrow_left_24;
                directionText = getString(R.string.direction_left);
                break;
            case 3:
                imageResource = R.drawable.baseline_arrow_right_24;
                directionText = getString(R.string.direction_right);
                break;
            default:
                imageResource = R.drawable.baseline_arrow_upward_24;
                directionText = getString(R.string.direction_top);
        }
        showDirection(imageResource, directionText);
    }

    private void showDirection(int imageResource, String directionText) {
        directionImageView.setImageResource(imageResource);
        directionTextView.setText(directionText);
    }
}