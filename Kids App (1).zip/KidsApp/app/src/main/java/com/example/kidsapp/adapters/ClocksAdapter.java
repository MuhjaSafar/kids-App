package com.example.kidsapp.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.kidsapp.R;
import com.example.kidsapp.databinding.ListClocksBinding;
import com.example.kidsapp.model.ClickListener;
import com.example.kidsapp.model.ClockModel;

import java.util.List;

public class ClocksAdapter extends RecyclerView.Adapter<ClocksAdapter.Vh> {
    int selected=0;
    List<ClockModel> list;
    Context context;
    ClickListener clickListener;

    public ClocksAdapter(List<ClockModel> list, Context context,ClickListener clickListener) {
        this.list = list;
        this.context = context;
        this.clickListener=clickListener;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.list_clocks,parent,false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {

        ClockModel clockModel=list.get(position);
        //holder.binding.tvTime.setText(clockModel.getHours()+":"+clockModel.getMinutes());
        holder.binding.tvTitle.setText(clockModel.getTitle());
    }

    //   @Override
/*
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        ClockModel clockModel=list.get(position);
       // holder.binding.tvTime.setText(clockModel.getHours()+":"+clockModel.getMinutes());
        holder.binding.tvTitle.setText(clockModel.getTitle());

        if (position==selected){
            holder.binding.cvAnalog.setCardBackgroundColor(Color.GREEN);
            holder.binding.tvTitle.setTextColor(Color.WHITE);
        //    holder.binding.tvTime.setTextColor(Color.WHITE);

        }else {
            holder.binding.cvAnalog.setCardBackgroundColor(Color.WHITE);
            holder.binding.tvTitle.setTextColor(Color.BLACK);
        //    holder.binding.tvTime.setTextColor(Color.BLACK);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int previous=selected;
                if (selected!=position){
                    clickListener.selected(position);
                    selected=position;
                    notifyItemChanged(selected);
                    notifyItemChanged(previous);
                }
            }
        });
    }
*/

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListClocksBinding binding;
        public Vh(@NonNull View itemView) {
            super(itemView);
            binding=ListClocksBinding.bind(itemView);
        }
    }
}
