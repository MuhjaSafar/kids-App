package com.example.kidsapp.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;
import com.example.kidsapp.databinding.FragmentHomeBinding;


public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        clickListeners();

        super.onViewCreated(view, savedInstanceState);
    }

    private void clickListeners() {
        binding.cvAnalog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_analogClockFragment);

            }
        });

        binding.cvDigitalClock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_digitalClockFragment);
            }
        });

        binding.cvSeasons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_seasonsFragment);
            }
        });

        binding.cvDaysOfTheWeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_weekDaysFragment);
            }
        });

        binding.cvMonths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_monthDaysFragment);
            }
        });
        binding.cvLearnMultiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_multiplicationFragment);
            }
        });
        binding.cvImageRecognition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_findSimilarImagesFragment);
            }
        });
        binding.cvLearnWritingSpelling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_spellingWritingFragment);
            }
        });

        binding.cvFocus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_ballFocusFragment);
            }
        });

        binding.cvLearnDirections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_learnDirectionsFragment);
            }
        });
        binding.cvLearnDigits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findNavController(HomeFragment.this).navigate(R.id.action_homeFragment2_to_digitMemorizationFragment);
            }
        });
    }
}