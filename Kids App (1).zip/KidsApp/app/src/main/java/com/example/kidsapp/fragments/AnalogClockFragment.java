package com.example.kidsapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.adapters.ClocksAdapter;
import com.example.kidsapp.databinding.FragmentAnalogClockBinding;
import com.example.kidsapp.model.ClockModel;

import java.util.List;


public class AnalogClockFragment extends Fragment {
    FragmentAnalogClockBinding binding;

    public AnalogClockFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAnalogClockBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.setTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour = Integer.parseInt(binding.hourEditText.getText().toString());
                int minute = Integer.parseInt(binding.minuteEditText.getText().toString());
                binding.analogClockView.setTime(hour, minute);
            }
        });
    }
}