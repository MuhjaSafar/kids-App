package com.example.kidsapp.fragments;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;

import java.util.ArrayList;
import java.util.List;

public class SpellingWritingFragment extends Fragment {

    private TextView wordTextView, resultTextView;
    private EditText userInputEditText;
    private Button checkButton;
    private List<String> wordsToSpell;
    private int currentWordIndex = 0;

    public SpellingWritingFragment() {
        // Initialize the list of words
        wordsToSpell = new ArrayList<>();
        wordsToSpell.add("apple");
        wordsToSpell.add("banana");
        wordsToSpell.add("orange");
        wordsToSpell.add("grape");
        wordsToSpell.add("watermelon");
        wordsToSpell.add("strawberry");
        wordsToSpell.add("pineapple");
        wordsToSpell.add("blueberry");
        wordsToSpell.add("kiwi");
        wordsToSpell.add("mango");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_spelling_writing, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        wordTextView = view.findViewById(R.id.wordTextView);
        userInputEditText = view.findViewById(R.id.userInputEditText);
        checkButton = view.findViewById(R.id.checkButton);
        resultTextView = view.findViewById(R.id.resultTextView);

        displayNextWord();

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkSpelling();
            }
        });
    }

    private void displayNextWord() {
        if (currentWordIndex < wordsToSpell.size()) {
            wordTextView.setText(String.format("%d. %s", currentWordIndex + 1, wordsToSpell.get(currentWordIndex)));
            userInputEditText.setText("");
        //    resultTextView.setText("");
            currentWordIndex++;

            // Hide the word after 3 seconds
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    wordTextView.setText("");
                }
            }, 3000);
        } else {
            wordTextView.setText(R.string.all_words_spelled_correctly);
            userInputEditText.setVisibility(View.GONE);
            checkButton.setVisibility(View.GONE);
        }
    }

    private void checkSpelling() {
        String userInput = userInputEditText.getText().toString().trim();
        String correctSpelling = wordsToSpell.get(currentWordIndex - 1);

        if (userInput.equalsIgnoreCase(correctSpelling)) {

            resultTextView.setText(R.string.great_you_spelled_the_word_correctly);
            displayNextWord();
        } else {
            resultTextView.setText(getString(R.string.incorrect_spelling_the_correct_spellings_are) + correctSpelling);
            displayNextWord();
        }
    }
}
