package com.example.kidsapp.fragments;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.kidsapp.R;
import com.example.kidsapp.adapters.MonthAdapter;
import com.example.kidsapp.databinding.FragmentMonthDaysBinding;
import com.example.kidsapp.model.ClickListener;
import com.example.kidsapp.model.MonthModel;

import java.util.ArrayList;
import java.util.List;

public class MonthDaysFragment extends Fragment {
    FragmentMonthDaysBinding binding;
    List<MonthModel> list;
    MonthAdapter adapter;
    MediaPlayer mediaPlayer;


    public MonthDaysFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMonthDaysBinding.inflate(inflater, container, false);

        mediaPlayer = new MediaPlayer();
        mediaPlayer = MediaPlayer.create(requireContext(), R.raw.months);

        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        list = new ArrayList<>();

        list.add(new MonthModel(getString(R.string.january)));
        list.add(new MonthModel(getString(R.string.febrary)));
        list.add(new MonthModel(getString(R.string.march)));
        list.add(new MonthModel(getString(R.string.april)));
        list.add(new MonthModel(getString(R.string.may)));
        list.add(new MonthModel(getString(R.string.june)));
        list.add(new MonthModel(getString(R.string.july)));
        list.add(new MonthModel(getString(R.string.august)));
        list.add(new MonthModel(getString(R.string.september)));
        list.add(new MonthModel(getString(R.string.octuber)));
        list.add(new MonthModel(getString(R.string.novemeber)));
        list.add(new MonthModel(getString(R.string.December)));

        binding.ivPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mediaPlayer.isPlaying()){
                    mediaPlayer.start();
                    binding.ivPlay.setImageResource(R.drawable.pause);
                }else {
                    mediaPlayer.pause();
                    binding.ivPlay.setImageResource(R.drawable.play);
                }
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                binding.ivPlay.setImageResource(R.drawable.play);
            }
        });

        adapter = new MonthAdapter(list, requireContext(), new ClickListener() {
            @Override
            public void selected(int position) {

            }
        });

        binding.rvWeekDays.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvWeekDays.setAdapter(adapter);
    }

    @Override
    public void onPause() {
        super.onPause();

        try {
            if (mediaPlayer!=null){
                if (mediaPlayer.isPlaying()){
                    mediaPlayer.release();
                }
            }
        }catch (Exception e){

        }

    }

}