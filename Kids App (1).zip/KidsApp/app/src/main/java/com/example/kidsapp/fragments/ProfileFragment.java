package com.example.kidsapp.fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;
import com.example.kidsapp.databinding.FragmentProfileBinding;
import com.example.kidsapp.model.UserData;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class ProfileFragment extends Fragment {

    FragmentProfileBinding binding;
    FirebaseDatabase database;
    ProgressDialog progressDialog;
    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentProfileBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        database=FirebaseDatabase.getInstance();
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
              progressDialog.hide();
                if (snapshot.exists()){
                    UserData data=snapshot.getValue(UserData.class);
                    binding.tvEmail.setText(data.getEmail());
                    binding.tvName.setText(data.getUserName());
                    binding.tvLanuage.setText(data.getLanguage());
                    if (data.getLanguage().equals("English")){
                        binding.tvLanuage.setText(R.string.english);
                    }else{
                        binding.tvLanuage.setText(R.string.t_rk_e);
                    }
                    int score=0;
                    if (data.getScore()==null){
                        score=0;
                    }else{
                        score=data.getScore();
                    }
                    binding.tvScore.setText("Score = "+score);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.hide();
                Toast.makeText(requireActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        binding.tvLanuage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                requireActivity().finish();
            }
        });

    }
    private void showPopupMenu() {
        Context context = requireContext();
        PopupMenu popupMenu = new PopupMenu(context, binding.tvLanuage);

        popupMenu.getMenuInflater().inflate(R.menu.menu_language, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.menu_english) {

                    Map<String,Object> update=new HashMap<>();
                    update.put("language",getString(R.string.english));
                    database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(update);
                    setAppLanguage("en");
                    return true;
                } else if (itemId == R.id.menu_turkish) {

                    Map<String,Object> update=new HashMap<>();
                    update.put("language",getString(R.string.t_rk_e));
                    database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(update);
                    setAppLanguage("tr");
                    return true;
                } else {
                    return false;
                }
            }

        });

        popupMenu.show();
    }
    private void setAppLanguage(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());

        requireActivity().recreate();
    }
}