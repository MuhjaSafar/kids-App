package com.example.kidsapp.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kidsapp.R;
import com.example.kidsapp.databinding.ListDaysBinding;
import com.example.kidsapp.model.ClickListener;
import com.example.kidsapp.model.WeekDays;

import java.util.List;

public class WeeksAdapter extends RecyclerView.Adapter<WeeksAdapter.Vh> {
    private String[] colors = {"#7F0000", "#005900", "#736800", "#7F3300"};

    List<WeekDays> list;
    Context context;
    ClickListener clickListener;

    public WeeksAdapter(List<WeekDays> list, Context context, ClickListener clickListener) {
        this.list = list;
        this.context = context;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_days, parent, false);
        return new Vh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vh holder, int position) {
        WeekDays clockModel = list.get(position);
        holder.binding.tvTitle.setText(clockModel.getTitle());
        holder.binding.cvAnalog.setCardBackgroundColor(Color.parseColor(colors[position % colors.length]));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ListDaysBinding binding;

        public Vh(@NonNull View itemView) {
            super(itemView);
            binding = ListDaysBinding.bind(itemView);
        }
    }
}