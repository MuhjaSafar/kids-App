package com.example.kidsapp.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
public class AnalogClockView extends View {

    private static final int HOUR_MARKER_INTERVAL = 5;
    private static final float HOUR_HAND_LENGTH_RATIO = 0.5f;
    private static final float MINUTE_HAND_LENGTH_RATIO = 0.8f;

    private int hour;
    private int minute;

    private Paint circlePaint;
    private Paint hourHandPaint;
    private Paint minuteHandPaint;
    private Paint textPaint;

    private float centerX;
    private float centerY;
    private float radius;

    public AnalogClockView(Context context) {
        super(context);
        init();
    }

    public AnalogClockView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        // Initialize paints for drawing
        circlePaint = createPaint(Color.BLACK, Paint.Style.STROKE);
        hourHandPaint = createPaint(Color.BLACK, Paint.Style.FILL_AND_STROKE, 8);
        minuteHandPaint = createPaint(Color.BLACK, Paint.Style.FILL_AND_STROKE, 4);
        textPaint = createPaint(Color.BLACK, Paint.Style.FILL_AND_STROKE, 30, Paint.Align.CENTER);
    }

    private Paint createPaint(int color, Paint.Style style) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setStyle(style);
        return paint;
    }

    private Paint createPaint(int color, Paint.Style style, float strokeWidth) {
        Paint paint = createPaint(color, style);
        paint.setStrokeWidth(strokeWidth);
        return paint;
    }

    private Paint createPaint(int color, Paint.Style style, float textSize, Paint.Align align) {
        Paint paint = createPaint(color, style);
        paint.setTextSize(textSize);
        paint.setTextAlign(align);
        return paint;
    }

    public void setTime(int hour, int minute) {
        this.hour = hour;
        this.minute = minute;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        calculateDimensions(w, h);
    }

    private void calculateDimensions(int width, int height) {
        centerX = width / 2f;
        centerY = height / 2f;
        radius = Math.min(centerX, centerY) - 20;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawBackgroundCircle(canvas);
        drawClockFace(canvas);
        drawHourHand(canvas);
        drawMinuteHand(canvas);
    }
    private void drawBackgroundCircle(Canvas canvas) {
        Paint backgroundCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundCirclePaint.setStyle(Paint.Style.STROKE);
        backgroundCirclePaint.setColor(Color.BLUE);
        backgroundCirclePaint.setStrokeWidth(1.5f);

        canvas.drawCircle(centerX, centerY, radius + 20, backgroundCirclePaint);
    }

    private void drawClockFace(Canvas canvas) {
        for (int i = 0; i < 60; i += HOUR_MARKER_INTERVAL) {
            float angle = calculateAngle(i * 6);
            float markerX = calculateXCoordinate(angle, radius - 30);
            float markerY = calculateYCoordinate(angle, radius - 30);
            canvas.drawCircle(markerX, markerY, 4, circlePaint);
            drawHourText(canvas, i, angle, radius - 60);
        }
        textPaint.setColor(Color.BLUE);
    }
    private void drawHourHand(Canvas canvas) {
        float hourAngle = calculateHourAngle();
        float hourHandLength = radius * HOUR_HAND_LENGTH_RATIO;
        float hourHandX = calculateXCoordinate((float) Math.toRadians(hourAngle), hourHandLength);
        float hourHandY = calculateYCoordinate((float) Math.toRadians(hourAngle), hourHandLength);
        canvas.drawLine(centerX, centerY, hourHandX, hourHandY, hourHandPaint);
    }

    private void drawHourText(Canvas canvas, int hourValue, float angle, float distanceFromCenter) {
        String hourText = String.valueOf(hourValue / HOUR_MARKER_INTERVAL);
        float textX = calculateXCoordinate(angle, distanceFromCenter);
        float textY = calculateYCoordinate(angle, distanceFromCenter);
        canvas.drawText(hourText, textX, textY, textPaint);
    }

    private float calculateAngle(int degrees) {
        return (float) Math.toRadians(degrees);
    }

    private float calculateXCoordinate(float angle, float distance) {
        return (float) centerX + (float) (distance * Math.sin(angle));

    }

    private float calculateYCoordinate(float angle, float distance) {
        return (float) centerY - (float) (distance * Math.cos(angle));
    }



    private float calculateHourAngle() {
        return (hour % 12 + minute / 60f) * 30f;
    }

    private void drawMinuteHand(Canvas canvas) {
        float minuteAngle = minute * 6f;
        float minuteHandLength = radius * MINUTE_HAND_LENGTH_RATIO;
        float minuteHandX = calculateXCoordinate((float) Math.toRadians(minuteAngle), minuteHandLength);
        float minuteHandY = calculateYCoordinate((float) Math.toRadians(minuteAngle), minuteHandLength);
        canvas.drawLine(centerX, centerY, minuteHandX, minuteHandY, minuteHandPaint);
    }
}