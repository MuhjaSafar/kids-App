package com.example.kidsapp.utils;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class BallView extends View {
    private static final int BALL_SIZE = 100;
    private static final int BALL_COLOR = Color.BLUE;

    private final Paint paint;
    private float x, y;
    private int maxX, maxY;

    public BallView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(BALL_COLOR);
        paint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(x, y, BALL_SIZE / 2, paint);
    }

    public void updatePosition() {
        Random random = new Random();
        x = random.nextInt(maxX - BALL_SIZE);
        y = random.nextInt(maxY - BALL_SIZE);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        maxX = w;
        maxY = h;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            x = event.getX();
            y = event.getY();
            invalidate();
            return true;
        }
        return false;
    }
}