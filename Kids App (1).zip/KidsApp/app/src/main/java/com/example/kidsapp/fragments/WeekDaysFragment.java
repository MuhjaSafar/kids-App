package com.example.kidsapp.fragments;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.kidsapp.R;
import com.example.kidsapp.adapters.WeeksAdapter;
import com.example.kidsapp.databinding.FragmentWeekDaysBinding;
import com.example.kidsapp.model.ClickListener;
import com.example.kidsapp.model.WeekDays;

import java.util.ArrayList;
import java.util.List;

public class WeekDaysFragment extends Fragment {
    FragmentWeekDaysBinding binding;
    List<WeekDays> list;
    WeeksAdapter adapter;
    MediaPlayer mediaPlayer;


    public WeekDaysFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentWeekDaysBinding.inflate(inflater, container, false);


        mediaPlayer = new MediaPlayer();
        mediaPlayer = MediaPlayer.create(requireContext(), R.raw.days);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        list = new ArrayList<>();
        list.add(new WeekDays(getString(R.string.sunday)));
        list.add(new WeekDays(getString(R.string.mondays)));
        list.add(new WeekDays(getString(R.string.tuesday)));
        list.add(new WeekDays(getString(R.string.wednesday)));
        list.add(new WeekDays(getString(R.string.thursday)));
        list.add(new WeekDays(getString(R.string.friday)));
        list.add(new WeekDays(getString(R.string.saturday)));

        binding.ivPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mediaPlayer.isPlaying()){
                    mediaPlayer.start();
                    binding.ivPlay.setImageResource(R.drawable.pause);
                }else {
                    mediaPlayer.pause();
                    binding.ivPlay.setImageResource(R.drawable.play);
                }
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                binding.ivPlay.setImageResource(R.drawable.play);
            }
        });

        adapter = new WeeksAdapter(list, requireContext(), new ClickListener() {
            @Override
            public void selected(int position) {

            }
        });
        binding.rvDays.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvDays.setAdapter(adapter);
    }

    @Override
    public void onPause() {
        super.onPause();

        try {
            if (mediaPlayer!=null){
                if (mediaPlayer.isPlaying()){
                    mediaPlayer.release();
                }
            }
        }catch (Exception e){

        }

    }
}