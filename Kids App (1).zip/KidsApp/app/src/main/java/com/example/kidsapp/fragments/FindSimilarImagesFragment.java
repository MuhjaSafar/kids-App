package com.example.kidsapp.fragments;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.kidsapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class FindSimilarImagesFragment extends Fragment {


    private GridLayout gridLayout;
    private Button checkBtn;
    private TextView resultTextView;
    private int score = 0;

    private ImageButton selectedButton1;
    private ImageButton selectedButton2;
    FirebaseDatabase database;
    int count;
    ProgressDialog progressDialog;

    public FindSimilarImagesFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_find_similar_images, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        gridLayout = view.findViewById(R.id.gridLayout);
        checkBtn = view.findViewById(R.id.checkBtn);
        resultTextView = view.findViewById(R.id.resultTextView);
        database = FirebaseDatabase.getInstance();
        selectedButton1 = null;
        selectedButton2 = null;
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        setupGame();

        checkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void setupGame() {

        List<ImageButton> imageButtons = new ArrayList<>();

        // Get references to all ImageButtons
        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            ImageButton imageButton = (ImageButton) gridLayout.getChildAt(i);
            imageButtons.add(imageButton);
        }

        // Shuffle the ImageButtons
        Collections.shuffle(imageButtons);

        for (int i = 0; i < imageButtons.size(); i++) {
            ImageButton imageButton = imageButtons.get(i);

            // Set images for ImageButtons
            int imageResourceId = getResources().getIdentifier("i" + (i + 1), "drawable", requireActivity().getPackageName());
            imageButton.setImageResource(imageResourceId);
            imageButton.setTag(String.valueOf(i + 1));

            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleImageSelection(v);
                }
            });
        }

        resultTextView.setText("");
    }

    private void handleImageSelection(View view) {
        ImageButton clickedButton = (ImageButton) view;

        if (selectedButton1 == null) {
            selectedButton1 = clickedButton;
            selectedButton1.setAlpha(0.5f); // Apply a visual cue to indicate selection
        } else if (selectedButton2 == null) {
            selectedButton2 = clickedButton;
            selectedButton2.setAlpha(0.5f);

            if (areImagesSimilar(selectedButton1, selectedButton2)) {
                resultTextView.setText(R.string.correct);
                count += 1;
                score += 10;
                selectedButton1.setAlpha(1.0f);
                selectedButton2.setAlpha(1.0f);
                // Set new selection
                selectedButton1 = null;
                selectedButton2 = null;
                setupGame();

            } else {
                resultTextView.setText(R.string.incorrect_try_again);
                count += 1;

                selectedButton1.setAlpha(1.0f);
                selectedButton2.setAlpha(1.0f);
                // Set new selection
                selectedButton1 = null;
                selectedButton2 = null;
                setupGame();
                //  resultTextView.setText("");
            }

        } else {
            // Reset previous selections
            selectedButton1.setAlpha(1.0f);
            selectedButton2.setAlpha(1.0f);

            // Set new selection
            selectedButton1 = clickedButton;
            selectedButton2 = null;
            selectedButton1.setAlpha(0.5f);
            resultTextView.setText("");
        }
        checkBtn.setText("Score = " + score);
        if (count == 5) {
            AlertDialog dialog = new AlertDialog.Builder(requireActivity())
                    .setTitle(R.string.game_over)
                    .setMessage(getString(R.string.your_total_score_is) + score)
                    .create();
            dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    progressDialog.show();
                    dialog.dismiss();
                    database.getReference("Users").child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                            .child("score").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        Integer dbScore = snapshot.getValue(Integer.class);
                                        if (dbScore == null) {
                                            dbScore = 0;
                                        }
                                        int totalScore = dbScore + score;
                                        database.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .child("score").setValue(totalScore).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        progressDialog.dismiss();
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(requireContext(), "Score Saved", Toast.LENGTH_SHORT).show();
                                                        } else {
                                                            Toast.makeText(requireContext(), "Failed to Store Score", Toast.LENGTH_SHORT).show();

                                                        }
                                                        findNavController(FindSimilarImagesFragment.this).navigateUp();

                                                    }
                                                });
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                }
            });
            dialog.setCancelable(false);
            dialog.show();


        }
    }


    private boolean areImagesSimilar(ImageButton imageButton1, ImageButton imageButton2) {
        int image1Index = Integer.parseInt(imageButton1.getTag().toString());
        int image2Index = Integer.parseInt(imageButton2.getTag().toString());

        // Compare the image indices to determine similarity
        return (image1Index == 1 && image2Index == 4) || (image1Index == 4 && image2Index == 1);
    }

    private void checkAnswer() {
        if (selectedButton1 != null && selectedButton2 != null) {
            if (areImagesSimilar(selectedButton1, selectedButton2)) {
                resultTextView.setText(R.string.correct);
            } else {
                resultTextView.setText(R.string.incorrect_try_again);
            }
            setupGame();
        }
    }
}