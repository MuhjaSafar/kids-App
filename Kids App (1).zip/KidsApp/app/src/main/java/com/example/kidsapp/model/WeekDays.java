package com.example.kidsapp.model;

public class WeekDays {
    String title;

    public WeekDays(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
